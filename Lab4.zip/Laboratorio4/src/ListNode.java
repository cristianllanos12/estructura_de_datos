public class ListNode {
    public ListNode former;
    public int pos;
    int val;
    ListNode next;

    ListNode(int val) {
        this.val = val;
        this.next = null;
    }
}
