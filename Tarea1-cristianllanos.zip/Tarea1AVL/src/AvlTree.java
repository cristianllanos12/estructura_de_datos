import java.util.Collections;
import java.util.Stack;


public class AvlTree {

    private NodoAvl root;
    private int totalnodes;

    public AvlTree() {
        root = null;
        totalnodes = 0;
    }

    //corrobora si el arbol está vacio
    public boolean checkEmpty() {
        return root == null;
    }

    //insertar elementos(Requiere la frase y la página, en ese orden)
    public void insertElement(String element, int pag) {
        root = insertElement(element, root, pag);
        totalnodes++;
    }

    //obtiene el peso del árbol
    private int getHeight(NodoAvl nodo) {
        return nodo == null ? -1 : nodo.h;
    }

    //revisa el peso máximo del lado derecho e izquierdo
    private int getMaxHeight(int leftNodoHeight, int rightNodoHeight) {
        return Math.max(leftNodoHeight, rightNodoHeight);
    }

    //metodo de inserción de nodos, revisa letra por letra porque pueden haber frases que empiesen similar

    private NodoAvl insertElement(String element, NodoAvl nodo, int pag) {
        if (nodo == null) {
            nodo = new NodoAvl(element, pag);
        } else {
            String eleComp = element.replaceAll("\\s+", "").toLowerCase();
            String nodoComp = nodo.element.replaceAll("\\s+", "").toLowerCase();
            if (eleComp.compareTo(nodoComp) == 0) {
                //Si el elemento es igual al del nodo actual
                nodo.addPaginas(pag);
                nodo.h = getMaxHeight(getHeight(nodo.leftChild), getHeight(nodo.rightChild)) + 1;
            } else {
                if (eleComp.compareTo(nodoComp) < 0) {
                    nodo.leftChild = insertElement(element, nodo.leftChild, pag);
                    if (getHeight(nodo.leftChild) - getHeight(nodo.rightChild) == 2) {
                        if (eleComp.compareTo(nodo.leftChild.element.
                                replaceAll("\\s+", "").toLowerCase()) < 0) {
                            nodo = rotateWithLeftChild(nodo);
                        } else {
                            nodo = doubleWithLeftChild(nodo);
                        }
                    }
                } else {
                    nodo.rightChild = insertElement(element, nodo.rightChild, pag);
                    if (getHeight(nodo.rightChild) - getHeight(nodo.leftChild) == 2) {
                        if (eleComp.compareTo(nodo.rightChild.element.
                                replaceAll("\\s+", "").toLowerCase()) < 0) {
                            nodo = rotateWithRightChild(nodo);
                        } else {
                            nodo = doubleWithRightChild(nodo);
                        }
                    }
                }
            }
        }
        // Actualizar la altura del nodo actual
        nodo.h = getMaxHeight(getHeight(nodo.leftChild), getHeight(nodo.rightChild)) + 1;
        return nodo;
    }

    //los siguientes metodos son de rotaciones para balancear el avl
    private NodoAvl rotateWithLeftChild(NodoAvl nodo2) {
        NodoAvl nodo1 = nodo2.leftChild;
        nodo2.leftChild = nodo1.rightChild;
        nodo1.rightChild = nodo2;
        nodo2.h = getMaxHeight(getHeight(nodo2.leftChild), getHeight(nodo2.rightChild)) + 1;
        nodo1.h = getMaxHeight(getHeight(nodo1.leftChild), nodo2.h) + 1;
        return nodo1;
    }

    private NodoAvl rotateWithRightChild(NodoAvl nodo1) {
        NodoAvl nodo2 = nodo1.rightChild;
        nodo1.rightChild = nodo2.leftChild;
        nodo2.leftChild = nodo1;
        nodo1.h = getMaxHeight(getHeight(nodo1.leftChild), getHeight(nodo1.rightChild)) + 1;
        nodo2.h = getMaxHeight(getHeight(nodo2.rightChild), nodo1.h) + 1;
        return nodo2;
    }

    private NodoAvl doubleWithLeftChild(NodoAvl nodo3) {
        nodo3.leftChild = rotateWithRightChild(nodo3.leftChild);
        return rotateWithLeftChild(nodo3);
    }

    private NodoAvl doubleWithRightChild(NodoAvl nodo1) {
        nodo1.rightChild = rotateWithLeftChild(nodo1.rightChild);
        return rotateWithRightChild(nodo1);
    }

    //Retorna el total de nodos del avl para temas de testeo
    public int getTotalNumberOfNodos() {
        return getTotalNumberOfNodos(root);
    }

    private int getTotalNumberOfNodos(NodoAvl head) {
        if (head == null) {
            return 0;
        } else {
            int length = 1;
            length = length + getTotalNumberOfNodos(head.leftChild);
            length = length + getTotalNumberOfNodos(head.rightChild);
            return length;
        }
    }

    //busca un nodo en concreto
    public boolean searchElement(String element) {
        return searchElement(root, element);
    }

    private boolean searchElement(NodoAvl head, String element) {
        boolean check = false;
        int count = 0;
        while ((head != null) && !check && count < element.length()) {
            String headElement = head.element;
            if ((int) element.charAt(count) < (int) headElement.charAt(count)) {
                head = head.leftChild;
            } else if ((int) element.charAt(count) > (int) headElement.charAt(count)) {
                head = head.rightChild;
            } else {
                if (headElement.equals(element)) {
                    check = true;
                    break;
                } else {
                    count++;
                }
            }
            check = searchElement(head, element);
        }
        return check;
    }

    //Retornar nodo
    public NodoAvl searchNode(NodoAvl root, String searchString) {
        if (root == null || root.element.equalsIgnoreCase(searchString)) {
            return root;
        }
        NodoAvl leftResult = searchNode(root.leftChild, searchString);
        if (leftResult != null) {
            return leftResult;
        }
        return searchNode(root.rightChild, searchString);
    }

    public NodoAvl getRoot() {
        return root;
    }

    private void print(NodoAvl n, String prefix) {
        if (n != null) {
            print(n.rightChild, prefix + "    ");
            System.out.println(prefix + "+-- " + n.element + " (" + n.h + ")");
            print(n.leftChild, prefix + "    ");
        }
    }

    public void print() {
        print(root, "");
    }


    //recorrido trnsversal in-orden
    public void inorder() {
        inorder(root);
    }

    public void printIndexInorder() {
        System.out.println();
        System.out.println("--- INDICE ---");
        char inicial = ' ';
        Stack<NodoAvl> stack = new Stack<>();
        NodoAvl actual = root;
        while (actual != null || !stack.isEmpty()) {
            while (actual != null) {
                stack.push(actual);
                actual = actual.leftChild;
            }
            actual = stack.pop();
            if (actual.element.charAt(0) != inicial) {
                inicial = actual.element.charAt(0);
                System.out.println("-" + inicial + "-");
            }
            System.out.print(actual.element + " ");
            printPages(actual);
            System.out.println();
            actual = actual.rightChild;
        }
        System.out.println("--- FIN INDICE ---");
        System.out.println();
    }

    //recorrido trnsversal in-orden
    public void inorderTraversal() {
        inorderTraversal(root);
    }

    private void inorderTraversal(NodoAvl head) {
        if (head != null) {
            inorderTraversal(head.leftChild);
            System.out.print(head.element + " ");
            inorderTraversal(head.rightChild);
        }
    }

    public void printPages(NodoAvl n) {
        Collections.sort(n.paginas);
        int size = n.paginas.size();
        for (int x = 0; x < size; x++) {
            if (size == 1) {
                System.out.print(n.paginas.get(x) + 1 + " ");
            } else {
                if (x < size - 1 && n.paginas.get(x).equals(n.paginas.get(x + 1))) {
                    int repeticiones = Collections.frequency(n.paginas, n.paginas.get(x));
                    System.out.print(n.paginas.get(x) + 1 + " (" + repeticiones + ")");
                    x += repeticiones - 1;
                } else {
                    if (x == size - 1) {
                        System.out.print(n.paginas.get(x) + 1 + " ");
                    } else {
                        System.out.print(n.paginas.get(x) + 1 + ", ");
                    }
                }
            }
        }
    }


    private void inorder(NodoAvl head) {
        if (head != null) {
            inorderTraversal(head.leftChild);
            if (head.equals(root)) {
                System.out.print(" /" + head.element + "/ ");
            } else {
                System.out.print(head.element + " ");
            }
            inorderTraversal(head.rightChild);
        }
    }
}
    

