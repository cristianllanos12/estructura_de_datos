import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        AvlTree elAvl = new AvlTree();
        Scanner file;
        try {
            file = new Scanner(new File("src/Libro.txt"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        int page = 0;
        boolean pageR;
        while (file.hasNextLine()) {
            pageR = false;
            String linea = file.nextLine();
            if (linea.charAt(linea.length() - 1) == '|') {//Asumimos que el | siempre se encuentra al final de la línea
                linea = linea.substring(0, linea.length() - 1);
                pageR = true;
            }
            if (linea.contains("\\")) {
                String[] separaciones = linea.split("\\\\");
                enviarAAVL(separaciones, page, elAvl);
            }
            if (pageR) {
                page++;
            }
        }
        Scanner sc = new Scanner(System.in);
        menu(sc, elAvl);
    }
    
    public static void menu(Scanner sc, AvlTree tree) {
        int op = 0;
        while (op != 3) {
            System.out.println("""
                    ---Menú principal---
                    1._ Crear índice
                    2._ Buscar un nodo
                    3._ Cerrar
                    """);
            
            System.out.print("Ingrese su opción: ");
            while (!sc.hasNextInt()) {
                System.out.println("Ingrese un dato apropiado");
                sc.next();
            }
            op = sc.nextInt();
            switch (op) {
                case 1 -> tree.printIndexInorder();
                case 2 -> {
                    sc.useDelimiter("\n");
                    if (tree.checkEmpty()) {
                        System.out.println("El arbol se encuentra vacío");
                    } else {
                        System.out.print("Ingrese palabra a buscar: ");
                        String searchString = sc.next();
                        NodoAvl nodoEncontrado = tree.searchNode(tree.getRoot(), searchString);
                        if (nodoEncontrado == null) {
                            System.out.println("La palabra no se encuentra en ningúna página");
                        } else {
                            System.out.print("la palabra se encuentra en las siguientes páginas: ");
                            tree.printPages(nodoEncontrado);
                        }
                    }
                }
                case 3 -> System.exit(83);
                default -> System.out.println("Por favor, ingrese una opción válida");
            }
        }
    }
    
    
    public static void enviarAAVL(String[] sarr, int page, AvlTree avl) {
        for (int x = 1; x < sarr.length; x += 2) {
            String swbs = sarr[x]; //SWBS significa "String without backSlash"
            avl.insertElement(swbs.trim(), page);
            //Aplicamos el método trim para que se reconozcan "  alo  " y "alo" como iguales
        }
    }
}
