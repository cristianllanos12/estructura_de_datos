import java.util.ArrayList;

public class NodoAvl {

    String element;  //es la frase
    ArrayList<Integer> paginas = new ArrayList<>(); //guarda las páginas en la que está la frase
    int h;  //height o peso
    NodoAvl leftChild;
    NodoAvl rightChild;

    //constructor por default 
    public NodoAvl() {
        leftChild = null;
        rightChild = null;
        element = "";
        h = 0;
    }

    // constructor
    public NodoAvl(String element, int pag) {
        leftChild = null;
        rightChild = null;
        this.element = element.toUpperCase().charAt(0) + element.substring(1, element.length()).toLowerCase();
        //asegura que la primera letra sea mayúscula
        h = 0;
        paginas.add(pag);
    }

    public void addPaginas(int pag) {  //funcion que añade más paginas al arrayList
        this.paginas.add(pag);
    }
    
    
}
